var o1 = {
    nom:"SAFI",
    prenom:"Amine"
};
var o2 = {
    nom:"SAFI",
    prenom:"Amine"
};
var tab = new Array();
tab.push(o1);
tab.push(o2);
tab.pop();
console.log(JSON.stringify(tab));

